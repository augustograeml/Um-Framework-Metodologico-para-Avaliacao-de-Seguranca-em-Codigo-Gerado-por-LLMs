from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Parameter(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    value = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return f'<Parameter {self.name}: {self.value}>'